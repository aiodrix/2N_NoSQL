package main

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"
	"sort"
)

// Block structure
type Block struct {
	PrevHash string `json:"prev_hash"`
	Data     string `json:"data"`
}

// Directory where the blocks are stored
var blockDir = "block/"

// Function to validate the blockchain
func isBlockchainValid() bool {
	// Get all block files
	blockFiles, err := filepath.Glob(blockDir + "*.block")
	if err != nil {
		fmt.Println("Error reading block directory:", err)
		return false
	}

	// Sort block files by modification time (oldest first)
	sort.Slice(blockFiles, func(i, j int) bool {
		infoI, _ := os.Stat(blockFiles[i])
		infoJ, _ := os.Stat(blockFiles[j])
		return infoI.ModTime().Before(infoJ.ModTime())
	})

	previousHash := "0" // Initial hash for the genesis block

	// Iterate over all blocks and validate
	for _, blockFile := range blockFiles {
		content, err := ioutil.ReadFile(blockFile)
		if err != nil {
			fmt.Println("Error reading block file:", blockFile)
			return false
		}

		var block Block
		if err := json.Unmarshal(content, &block); err != nil {
			fmt.Println("Invalid block format:", filepath.Base(blockFile))
			return false
		}

		// Calculate hash of the current block
		hash := sha256.Sum256(content)
		calculatedHash := fmt.Sprintf("%x", hash)

		// Check if the block's previous hash matches the stored previous hash
		if block.PrevHash != previousHash {
			fmt.Println("Blockchain broken at block:", filepath.Base(blockFile))
			return false
		}

		// Update previous hash for the next iteration
		previousHash = calculatedHash
	}

	return true
}

func main() {
	if isBlockchainValid() {
		fmt.Println("The blockchain is valid.")
	} else {
		fmt.Println("The blockchain is invalid.")
	}
}
