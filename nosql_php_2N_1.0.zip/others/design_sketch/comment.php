<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Chat</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 100%;
            max-width: 800px;
            margin: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        input[type="text"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #008cba;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #005f73;
        }

        .comments {
            margin-top: 20px;
        }

        .comment {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }

        .comment:last-child {
            border-bottom: none;
        }

        .comment b {
            color: #008cba;
        }

        .image-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .image-container img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .back-link {
            display: block;
            margin-top: 10px;
            color: #008cba;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
            if (!is_dir("comments")) {
                mkdir("comments");
            }

            $leftTableSize = file_exists($_GET['hash']) ? "50" : "0";
            $folder = 'comments';
            $date = date('Y-m-d');

            if(isset($_GET['hash'])){
                $getHash = $_GET['hash'];
                echo "<div class='image-container'>";
                echo $img = $leftTableSize ? "<a href='$getHash'><img src='$getHash' alt='Sketch Image'></a>" : "";
                echo "<a href='index.php' class='back-link'>Back</a>";
                echo "</div>";
            }

            $fileHash = isset($_GET['hash']) ? sha1($_GET['hash']) : sha1($date);
            $filePath = "$folder/$fileHash";

            if (isset($_POST['submit'])) {
                $name = htmlspecialchars($_POST['name']);
                $message = htmlspecialchars($_POST['message']);
                $messageHash = sha1("$name $message");
                $messageWrite = "<div class='comment'><a href='comment.php?hash=$messageHash'>[comment]</a> $date <b>$name</b> : $message</div>";

                $file = fopen($filePath, 'a');
                fwrite($file, $messageWrite);
                fclose($file);
            }

            echo "<div class='comments'>";
            if (file_exists($filePath)) {
                echo file_get_contents($filePath);
            } else {
                echo "<div class='comment'><u>No comments yet.</u></div>";
            }
            echo "</div>";
        ?>

        <form method="post" action="">
            <input type="text" name="name" placeholder="Username" required>
            <input type="text" name="message" placeholder="Message" required>
            <input type="submit" name="submit" value="Submit">
        </form>
    </div>
</body>
</html>
