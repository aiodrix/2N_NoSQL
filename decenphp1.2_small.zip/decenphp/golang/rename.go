package main

import (
	"crypto/sha1"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"os"
	"path/filepath"
)

func main() {
	artFolder := "art" // Folder containing the directories

	// Get all directories inside the "art" folder
	dirs, err := ioutil.ReadDir(artFolder)
	if err != nil {
		log.Fatalf("Failed to read directory %s: %v", artFolder, err)
	}

	for _, dir := range dirs {
		if dir.IsDir() {
			dirPath := filepath.Join(artFolder, dir.Name())

			// Get all files inside the current directory
			files, err := ioutil.ReadDir(dirPath)
			if err != nil {
				log.Printf("Failed to read directory %s: %v", dirPath, err)
				continue
			}

			for _, file := range files {
				if !file.IsDir() {
					filePath := filepath.Join(dirPath, file.Name())
					hash, err := computeSHA1(filePath)
					if err != nil {
						log.Printf("Failed to compute SHA1 for file %s: %v", filePath, err)
						continue
					}

					newFileName := hash + ".jpg"
					newFilePath := filepath.Join(dirPath, newFileName)

					// Rename the file
					err = os.Rename(filePath, newFilePath)
					if err != nil {
						log.Printf("Failed to rename file %s to %s: %v", filePath, newFilePath, err)
					} else {
						fmt.Printf("Renamed: %s -> %s\n", filePath, newFilePath)
					}
				}
			}
		}
	}
}

// computeSHA1 calculates the SHA1 hash of a given file.
func computeSHA1(filePath string) (string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer file.Close()

	hash := sha1.New()
	if _, err := io.Copy(hash, file); err != nil {
		return "", err
	}

	return fmt.Sprintf("%x", hash.Sum(nil)), nil
}
