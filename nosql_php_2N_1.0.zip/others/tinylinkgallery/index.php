<?php
function isValidImageExtension($url) {
    $validExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
    $extension = strtolower(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
    return in_array($extension, $validExtensions);
}

function isValidLink($variable) {
    // Use PHP's filter_var function with the FILTER_VALIDATE_URL filter
    if (filter_var($variable, FILTER_VALIDATE_URL)) {
        return true; // It's a valid URL
    } else {
        return false; // It's not a valid URL
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $imageLink = $_POST["image_link"];
    $categories = $_POST["categories"];
    
    if (!isValidLink($imageLink)) {
        
        $redirectPage = $imageLink ? $imageLink : $categories;

        $redirectTo = "img_html/" . $redirectPage . ".html";
        header("Location: $redirectTo");
        exit();

    } else {

        $imageType = isValidImageExtension($imageLink);

        if (!$imageType){echo "Wrong image type!"; die;}

        // Create img_html directory if it doesn't exist
        $directory = "img_html";
        if (!file_exists($directory)) {
            mkdir($directory, 0777, true);
        }
        
        $categoryArray = explode(",", $categories);
        
        foreach ($categoryArray as $category) {
            $category = trim($category);
            $fileName = $directory . "/" . $category . ".html";
            $fileContent = "<a class='crop' href='$imageLink' target='_blank'><img src='$imageLink' alt='$category'></a>";
            
            $file = fopen($fileName, "a+");
            if ($file) {
                if (filesize($fileName) == 0) {
                    $fileContent = "<link rel='stylesheet' href='../img.css'><script src='../img_js.js'></script>" . $fileContent;
                }
                fwrite($file, $fileContent);
                fclose($file);
            } else {
                echo "Unable to open file: $fileName<br>";
            }
        }
        
        echo "Files created or updated successfully! <a href='$fileName'>View</a>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tinylinkgallery</title>
    <style>
        /* Global Styles */
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background: linear-gradient(to right, #2c3e50, #3498db);
        }

        h2 {
            color: #ffffff;
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5em;
        }

        .description {
            background: linear-gradient(45deg, #8e44ad, #ffffff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            font-size: 1.2em;
            text-align: center;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        form {
            background-color: #f7f9fb;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        input[type="text"] {
            width: 100%;
            padding: 15px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 1.1em;
            transition: border-color 0.3s;
        }

        input[type="text"]::placeholder {
            color: #aaa;
        }

        input[type="text"]:focus {
            border-color: #3498db;
            outline: none;
        }

        input[type="submit"] {
            width: 100%;
            padding: 15px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.2em;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #2980b9;
            transform: translateY(-3px);
        }

        .download-btn {
            display: block;
            text-align: center;
            padding: 15px;
            margin-top: 20px;
            background: linear-gradient(45deg, #ff6b6b, #feca57);
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
            font-size: 1.2em;
            transition: background 0.3s ease, transform 0.3s ease;
        }

        .download-btn:hover {
            background: linear-gradient(45deg, #ff5252, #ffc107);
            transform: translateY(-3px);
        }
    </style>
</head>

<body>

    <p class="description">
        This tool allows you to create galleries from different images from the web.
        Simply enter an image URL and a list of categories, and we'll generate the files for you. 
        It's a quick way to organize images across multiple categories!
    </p>

    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <input type="text" id="image_link" name="image_link" placeholder="Enter the image link (URL) or category for search">

        <input type="text" id="categories" name="categories"
            placeholder="Enter categories separated by commas (e.g., nature, animals, food)">

        <input type="submit" value="Generate Gallery">
    </form>

    <a href="https://twitter.com/2_nodes" class="download-btn">Download Source Code</a>
</body>

</html>
