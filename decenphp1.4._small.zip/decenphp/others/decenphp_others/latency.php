<?php

// Function to get the latency of a server
function getLatency($url) {
    $startTime = microtime(true);
    
    // Initialize a cURL session
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5); // Set timeout to 5 seconds
    curl_exec($ch);
    
    // Check if there's an error
    if (curl_errno($ch)) {
        curl_close($ch);
        return false; // Server is offline
    }
    
    $endTime = microtime(true);
    curl_close($ch);
    
    // Calculate latency in milliseconds
    return round(($endTime - $startTime) * 1000);
}

// Directory containing the server files
$serversDir = 'servers';

// Get all files in the 'servers' directory
$files = glob($serversDir . '/*');

// Loop through each file
foreach ($files as $file) {
    if (is_file($file)) {
        // Read the server URL from the file
        $url = file_get_contents($file);
        
        // Ensure it's a valid URL
        if (filter_var($url, FILTER_VALIDATE_URL)) {
            // Get the latency
            $latency = getLatency($url);
            
            if ($latency === false) {
                // If no latency or offline, delete the file
                unlink($file);
                echo "Deleted: $file (Offline or no latency)\n";
            } else {
                // Generate a new filename with latency and random characters
                $newName = $serversDir . '/' . $latency . '_' . generateRandomString(4) . '.txt';
                
                // Rename the file with the new name
                rename($file, $newName);
                echo "Renamed: $file to $newName (Latency: $latency ms)<br>";
            }
        } else {
            echo "Invalid URL in file: $file\n";
        }
    }
}

// Function to generate a random string of specified length
function generateRandomString($length = 4) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

?>
