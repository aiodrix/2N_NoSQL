package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"html/template"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

const uploadDirectory = "./files/"

func main() {
	http.HandleFunc("/", uploadForm)
	http.HandleFunc("/upload", uploadHandler)

	// Create the directory if it doesn't exist
	if _, err := os.Stat(uploadDirectory); os.IsNotExist(err) {
		err = os.Mkdir(uploadDirectory, 0777)
		if err != nil {
			log.Fatalf("Failed to create directory: %v", err)
		}
	}

	log.Println("Server started at :8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

// uploadForm renders the file upload form
func uploadForm(w http.ResponseWriter, r *http.Request) {
	tmpl := template.Must(template.New("form").Parse(formTemplate))
	tmpl.Execute(w, nil)
}

// uploadHandler handles file uploads
func uploadHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Parse multipart form
	err := r.ParseMultipartForm(10 << 20) // 10 MB limit
	if err != nil {
		http.Error(w, "File too big", http.StatusBadRequest)
		return
	}

	// Get the uploaded file
	file, handler, err := r.FormFile("uploaded_file")
	if err != nil {
		fmt.Fprintln(w, "No files uploaded.")
		return
	}
	defer file.Close()

	// Check file extension
	fileName := handler.Filename
	fileExtension := strings.ToLower(filepath.Ext(fileName))
	if fileExtension == ".php" {
		fmt.Fprintln(w, "PHP files are not allowed.")
		return
	}

	// Generate unique filename based on SHA256 hash
	hash := sha256.New()
	if _, err := io.Copy(hash, file); err != nil {
		http.Error(w, "Failed to generate file hash", http.StatusInternalServerError)
		return
	}
	fileHash := hex.EncodeToString(hash.Sum(nil))
	newFileName := fileHash + fileExtension

	// Reset file pointer to beginning after hashing
	file.Seek(0, 0)

	// Full path to save file
	filePath := filepath.Join(uploadDirectory, newFileName)

	// Check if file already exists
	if _, err := os.Stat(filePath); !os.IsNotExist(err) {
		fmt.Fprintf(w, "File already exists. Cannot overwrite existing files.")
		return
	}

	// Create the file in the specified directory
	dst, err := os.Create(filePath)
	if err != nil {
		http.Error(w, "Failed to save file", http.StatusInternalServerError)
		return
	}
	defer dst.Close()

	// Copy uploaded file to destination
	if _, err := io.Copy(dst, file); err != nil {
		http.Error(w, "Failed to save file", http.StatusInternalServerError)
		return
	}

	fmt.Fprintf(w, "File uploaded successfully. File path: %s\n", filePath)
}

const formTemplate = `
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>File Upload Receiver</title>
</head>
<body>
    <h1>Upload File</h1>
    <form action="/upload" method="post" enctype="multipart/form-data">
        <label for="uploaded_file">Choose file to upload:</label><br>
        <input type="file" name="uploaded_file" id="uploaded_file"><br><br>
        <input type="submit" value="Upload File">
    </form>
</body>
</html>
`
