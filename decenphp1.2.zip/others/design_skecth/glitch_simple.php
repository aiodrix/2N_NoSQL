<?php
function glitchImage($imgPath) {
    // Ensure the glitch directory exists
    $glitchDir = 'glitch';
    if (!file_exists($glitchDir)) {
        mkdir($glitchDir, 0777, true);
    }

    // Get the image file's contents as a binary string
    $imgBytes = file_get_contents($imgPath);
    if ($imgBytes === false) {
        die("Failed to read image file.");
    }

    // Determine how many bytes to modify (random between 5 and 20)
    $numBytesToChange = rand(5, 20);

    // Get the length of the image data
    $imgLength = strlen($imgBytes);

    // Change random bytes
    for ($i = 0; $i < $numBytesToChange; $i++) {
        // Select a random position in the image data
        $randomPosition = rand(0, $imgLength - 1);
        
        // Randomly change a byte
        $randomByte = chr(rand(0, 255));
        
        // Modify the byte at the selected position
        $imgBytes[$randomPosition] = $randomByte;
    }

    // Save the modified image in the 'glitch' folder
    $glitchFilePath = $glitchDir . '/glitched_' . basename($imgPath);
    file_put_contents($glitchFilePath, $imgBytes);

    // Return the path to the glitched image
    return $glitchFilePath;
}

// Get the image path from the GET parameter 'img'
if (isset($_GET['img'])) {
    $imgPath = $_GET['img'];

    // Check if the file exists and is an image
    if (file_exists($imgPath) && exif_imagetype($imgPath)) {
        // Glitch the image
        $glitchedImage = glitchImage($imgPath);

        // Output the result
        echo "<h1>Glitched Image</h1>";
        echo "<img src='$glitchedImage' alt='Glitched Image'>";
    } else {
        echo "Invalid image path.";
    }
} else {
    echo "Please provide an image path using the 'img' GET parameter.";
}
?>
