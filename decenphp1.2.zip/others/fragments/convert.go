package main

import (
    "crypto/sha256"
    "encoding/base64"
    "fmt"
    "io/ioutil"
    "os"
    "path/filepath"
    "strings"
)

func main() {
    // Size of each chunk (most browsers support a value between 256 and 64000)
    chunkSize := 8000

    hashPath := "fragments"
    filesPath := "files"

    // Directory containing the files to be converted and splitted
    files, err := ioutil.ReadDir(filesPath)
    if err != nil {
        fmt.Println("Error:", err)
        return
    }

    for _, fileInfo := range files {
        filePath := filepath.Join(filesPath, fileInfo.Name())

        // Get file contents
        fileContent, err := ioutil.ReadFile(filePath)
        if err != nil {
            fmt.Println("Error:", err)
            continue
        }

        // Convert file to base64
        encodedData := base64.StdEncoding.EncodeToString(fileContent)

        // Get hash
        hasher := sha256.New()
        hasher.Write([]byte(encodedData))
        fileHash := strings.ToLower(fmt.Sprintf("%x", hasher.Sum(nil)))

        var hashes []string

        // Split file into chunks
        for x := 0; ; x++ {
            chunkStart := chunkSize * x
            if chunkStart >= len(encodedData) {
                break
            }
            chunkEnd := chunkStart + chunkSize
            if chunkEnd > len(encodedData) {
                chunkEnd = len(encodedData)
            }
            chunk := encodedData[chunkStart:chunkEnd]

            // Get hash of each chunk
            hasher.Reset()
            hasher.Write([]byte(chunk))
            hash := strings.ToLower(fmt.Sprintf("%x", hasher.Sum(nil)))

            hashes = append(hashes, hash)

            // Write the chunks of file
            chunkFile, err := os.Create(filepath.Join(hashPath, hash))
            if err != nil {
                fmt.Println("Error:", err)
                continue
            }
            _, err = chunkFile.Write([]byte(chunk))
            if err != nil {
                fmt.Println("Error:", err)
            }
            chunkFile.Close()
        }

        // Create a file (key) with the order of the chunks of a file
        keyFile, err := os.Create(filepath.Join("keys", fileHash))
        if err != nil {
            fmt.Println("Error:", err)
            continue
        }
        _, err = keyFile.WriteString(strings.Join(hashes, ","))
        if err != nil {
            fmt.Println("Error:", err)
        }
        keyFile.Close()
    }

    fmt.Println("Files converted.")
}
