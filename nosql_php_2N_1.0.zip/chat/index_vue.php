<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!empty($_POST['category'])) {
        $_SESSION['category'] = htmlspecialchars(trim($_POST['category']), ENT_QUOTES, 'UTF-8');
        header('Location: messages.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Chat</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .landing-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-color: #fff;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .landing-container h1 {
            font-size: 36px;
            color: #007bff;
            margin-bottom: 20px;
        }
        .landing-container input {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            width: 300px;
            margin-bottom: 20px;
        }
        .landing-container button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .landing-container button:hover {
            background-color: #0056b3;
        }
        .slide-in {
            animation: slide-in 0.5s ease-in-out;
        }
        .slide-out {
            animation: slide-out 0.5s ease-in-out;
        }
        @keyframes slide-in {
            0% {
                transform: translateY(-100%);
            }
            100% {
                transform: translateY(0);
            }
        }
        @keyframes slide-out {
            0% {
                transform: translateY(0);
            }
            100% {
                transform: translateY(-100%);
            }
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
</head>
<body>
    <div id="app" class="landing-container">
        <h1>Welcome to the PHP Chat</h1>
        <form method="post" action="">
            <input type="text" name="category" v-model="category" placeholder="Enter a category or group name" />
            <button type="button" @click="submitCategory" :class="{ 'slide-in': showAnimation, 'slide-out': !showAnimation }">Go to Chat</button>
        </form>
    </div>

    <script>
        new Vue({
            el: '#app',
            data: {
                category: '',
                showAnimation: false
            },
            methods: {
                submitCategory() {
                    if (this.category.trim() !== '') {
                        this.showAnimation = true;
                        setTimeout(() => {
                            this.showAnimation = false;
                            this.$el.querySelector('form').submit();
                        }, 500);
                    }
                }
            }
        });
    </script>
</body>
</html>
