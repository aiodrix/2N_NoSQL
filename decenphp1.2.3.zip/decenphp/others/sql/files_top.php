<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "decenphp";

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the 'files' table if it doesn't exist
$tableQuery = "
    CREATE TABLE IF NOT EXISTS files (
        id INT AUTO_INCREMENT PRIMARY KEY,
        filehash VARCHAR(64) UNIQUE NOT NULL,
        weight FLOAT NOT NULL,
        user VARCHAR(50) NOT NULL
    )
";
if ($conn->query($tableQuery) === TRUE) {
    echo "Table 'files' created or already exists.<br>";
} else {
    die("Error creating table: " . $conn->error);
}

// Insert sample data (optional)
$sampleData = [
    ['filehash' => hash('sha256', 'file1'), 'weight' => 1.2, 'user' => 'Alice'],
    ['filehash' => hash('sha256', 'file2'), 'weight' => 10.8, 'user' => 'Bob'],
    ['filehash' => hash('sha256', 'file3'), 'weight' => 12.5, 'user' => 'Alice'],
    ['filehash' => hash('sha256', 'file4'), 'weight' => 22.3, 'user' => 'Charlie'],
    // ... add more sample data as needed for testing
];

foreach ($sampleData as $data) {
    $insertQuery = $conn->prepare("INSERT IGNORE INTO files (filehash, weight, user) VALUES (?, ?, ?)");
    $insertQuery->bind_param("sds", $data['filehash'], $data['weight'], $data['user']);
    $insertQuery->execute();
}

// Function to display the top 100 files by weight
function getTop100FilesByWeight($conn) {
    // Query to get the top 100 files with the highest weight
    $topFilesQuery = "SELECT filehash, weight, user FROM files ORDER BY weight DESC LIMIT 100";
    $result = $conn->query($topFilesQuery);

    // Display the results in a table
    echo "<h2>Top 100 Files by Weight</h2>";
    echo "<table border='1'>";
    echo "<tr><th>File Hash</th><th>Weight</th><th>User</th></tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['filehash']) . "</td>";
        echo "<td>" . number_format($row['weight'], 2) . "</td>";
        echo "<td>" . htmlspecialchars($row['user']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Display the top 100 files by weight
getTop100FilesByWeight($conn);

// Close the database connection
$conn->close();
?>
