package main

import (
	"fmt"
	"net/http"
	"os"
	"path/filepath"
)

func main() {
	// Load the sitenames and TLDs
	sitenames := []string{"paste"}
	tlds := []string{"com", "net", "org"} // Replace this with the actual TLDs from the 'tlds.php' file

	// Directories for storing URLs
	directories := map[string]string{
		"online":  "online",
		"offline": "offline",
	}

	// Ensure the directories exist
	for _, dir := range directories {
		if _, err := os.Stat(dir); os.IsNotExist(err) {
			err = os.MkdirAll(dir, 0755)
			if err != nil {
				fmt.Printf("Error creating directory %s: %v\n", dir, err)
				return
			}
		}
	}

	// Iterate over sitenames and TLDs
	for _, name := range sitenames {
		for _, tld := range tlds {
			filenameOnline := filepath.Join(directories["online"], fmt.Sprintf("%s.%s.txt", name, tld))
			filenameOffline := filepath.Join(directories["offline"], fmt.Sprintf("%s.%s.txt", name, tld))

			// Skip if either online or offline file already exists
			if fileExists(filenameOnline) || fileExists(filenameOffline) {
				continue
			}

			url := fmt.Sprintf("http://%s.%s", name, tld)
			resp, err := http.Head(url)

			if err == nil && resp.StatusCode == http.StatusOK {
				fmt.Printf("%s.%s is online\n", name, tld)
				saveToFile(filenameOnline)
			} else {
				fmt.Printf("%s.%s is offline or unreachable\n", name, tld)
				saveToFile(filenameOffline)
			}
		}
	}

	fmt.Println("URL check completed.")
}

// saveToFile creates an empty file
func saveToFile(filename string) {
	file, err := os.Create(filename)
	if err != nil {
		fmt.Printf("Error: Unable to create file %s: %v\n", filename, err)
		return
	}
	defer file.Close()
	_, _ = file.WriteString("") // Just create an empty file
}

// fileExists checks if a file exists
func fileExists(filename string) bool {
	_, err := os.Stat(filename)
	return !os.IsNotExist(err)
}
