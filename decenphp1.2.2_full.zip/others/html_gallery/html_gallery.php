<?php

function main() {
    $root = "./arts";
    $rootIndexContent = "<html><body><ul>"; // Content for the main index.html

    // Walk through the directory and handle directories
    $files = scandir($root);
    foreach ($files as $file) {
        $path = $root . '/' . $file;
        if (is_dir($path) && $file != '.' && $file != '..') {
            // Get the list of files in the directory
            $filesInDir = array_filter(scandir($path), 'isImage'); // Only get image files
            if (!empty($filesInDir)) {
                // Create the HTML content with img tags for this directory
                $htmlContent = "<html><body><div align='center'>";
                foreach ($filesInDir as $fileInDir) {
                    // Set the src attribute with only the file name
                    $src = $fileInDir;
                    $htmlContent .= "<a href=\"$src\"><img src=\"$src\" width=\"50%\"></a><br><br>";
                }
                $htmlContent .= "</div></body></html>";

                // Write HTML content to a file in the directory
                $htmlFilePath = $path . "/index.html";
                file_put_contents($htmlFilePath, $htmlContent);

                // Add link to the root index.html for this directory
                $rootIndexContent .= "<li><a href=\"$path/index.html\">$file</a><br>";

                // Select up to 5 random images to show as thumbnails in root index
                $randomImages = array_slice($filesInDir, 0, 5); // Limit to first 5 or less
                shuffle($randomImages); // Randomize the images
                foreach ($randomImages as $img) {
                    $imgSrc = "$file/$img";
                    $rootIndexContent .= "<img src=\"arts/$imgSrc\" width=\"100\" style=\"margin: 5px;\">";
                }

                $rootIndexContent .= "</li>";
            }

            echo "Created HTML file: $htmlFilePath\n";
        }
    }

    // Finalize and write the main index.html
    $rootIndexContent .= "</ul></body></html>";
    file_put_contents($root . "/../index.html", $rootIndexContent);

    echo "Created root index.html\n";
}

// isImage checks if a file is an image based on its extension
function isImage($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, ['jpg', 'jpeg', 'png', 'gif']);
}

main();

?>
