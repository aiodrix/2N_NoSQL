<?php

// Path to the 'servers' folder
$serversDir = 'servers';

// Check if the 'servers' directory exists
if (!is_dir($serversDir)) {
    die("Directory '$serversDir' does not exist.");
}

// Function to check the URL using cURL
function checkUrl($url) {
    // Initialize a cURL session
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);  // Timeout after 10 seconds

    // Execute the cURL request
    $response = curl_exec($ch);

    // Check for cURL errors
    if ($response === false) {
        echo "<p style='color: red;'>Failed to connect to $url: " . curl_error($ch) . "</p>";
    } else {
        echo "<p style='color: green;'>Successfully connected to $url</p>";
    }

    // Close the cURL session
    curl_close($ch);
}

echo "<h2>Attempting to connect to URLs from files in the 'servers' folder:</h2>";

// Open the directory
$files = scandir($serversDir);

foreach ($files as $file) {
    // Skip '.' and '..'
    if ($file === '.' || $file === '..') {
        continue;
    }

    // Get the full path to the file
    $filePath = $serversDir . DIRECTORY_SEPARATOR . $file;

    // Check if it's a regular file
    if (is_file($filePath)) {
        echo "<p><strong>File:</strong> $file</p>";

        // Get the file content
        $fileContent = file_get_contents($filePath);

        // Attempt to connect to the URL (assuming the file contains a URL)
        if (filter_var($fileContent, FILTER_VALIDATE_URL)) {
            echo "<p>Attempting connection to: <a href='$fileContent' target='_blank'>$fileContent</a></p>";
            
            // Use the function to check the URL
            checkUrl($fileContent);
        } else {
            echo "<p style='color: orange;'>Invalid URL or empty file content.</p>";
        }
    }
}
