<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "decenphp";

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the 'files' table if it doesn't exist
$tableQuery = "
    CREATE TABLE IF NOT EXISTS files (
        id INT AUTO_INCREMENT PRIMARY KEY,
        filehash VARCHAR(64) UNIQUE NOT NULL,
        weight FLOAT NOT NULL,
        user VARCHAR(50) NOT NULL
    )
";
if ($conn->query($tableQuery) === TRUE) {
    echo "Table 'files' created or already exists.<br>";
} else {
    die("Error creating table: " . $conn->error);
}

// Insert sample data (optional)
$sampleData = [
    ['filehash' => hash('sha256', 'file1'), 'weight' => 1.2, 'user' => 'Alice'],
    ['filehash' => hash('sha256', 'file2'), 'weight' => 0.8, 'user' => 'Bob'],
    ['filehash' => hash('sha256', 'file3'), 'weight' => 1.5, 'user' => 'Alice'],
    ['filehash' => hash('sha256', 'file4'), 'weight' => 2.3, 'user' => 'Charlie']
];

foreach ($sampleData as $data) {
    $insertQuery = $conn->prepare("INSERT IGNORE INTO files (filehash, weight, user) VALUES (?, ?, ?)");
    $insertQuery->bind_param("sds", $data['filehash'], $data['weight'], $data['user']);
    $insertQuery->execute();
}

// Function to calculate the user percentages based on weight
function getUserWeightedPercentage($conn) {
    // Calculate the total weighted score for all users
    $totalWeightQuery = "
        SELECT SUM(weight * file_count) AS total_weighted_score
        FROM (SELECT user, SUM(weight) AS weight, COUNT(*) AS file_count FROM files GROUP BY user) AS user_weights
    ";
    $result = $conn->query($totalWeightQuery);
    $totalWeightedScore = $result->fetch_assoc()['total_weighted_score'];

    // Calculate each user's weighted score and percentage
    $userWeightQuery = "
        SELECT user, SUM(weight) AS total_weight, COUNT(*) AS file_count,
               (SUM(weight) * COUNT(*)) AS user_weighted_score
        FROM files
        GROUP BY user
    ";
    $result = $conn->query($userWeightQuery);

    // Display the results
    echo "<table border='1'>";
    echo "<tr><th>User</th><th>File Count</th><th>Total Weight</th><th>Weighted Score</th><th>Percentage of Total</th></tr>";

    while ($row = $result->fetch_assoc()) {
        $user = $row['user'];
        $fileCount = $row['file_count'];
        $totalWeight = $row['total_weight'];
        $userWeightedScore = $row['user_weighted_score'];
        $percentage = ($userWeightedScore / $totalWeightedScore) * 100;

        echo "<tr>";
        echo "<td>" . htmlspecialchars($user) . "</td>";
        echo "<td>" . htmlspecialchars($fileCount) . "</td>";
        echo "<td>" . number_format($totalWeight, 2) . "</td>";
        echo "<td>" . number_format($userWeightedScore, 2) . "</td>";
        echo "<td>" . number_format($percentage, 2) . "%</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Display user weighted percentages
getUserWeightedPercentage($conn);

// Close the database connection
$conn->close();
?>
