window.onload = function() {
    const images = document.querySelectorAll('.crop img');
    const targetWidth = window.innerWidth * 0.3;

    images.forEach(img => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');

        img.onload = () => {
            const { width: imgWidth, height: imgHeight } = img;

            // Calculate crop dimensions for a square crop
            const cropSize = Math.min(imgWidth, imgHeight);
            const cropX = (imgWidth - cropSize) / 2;
            const cropY = (imgHeight - cropSize) / 2;

            // Set canvas dimensions and draw the cropped image
            canvas.width = targetWidth;
            canvas.height = targetWidth; // Maintain square aspect ratio
            ctx.drawImage(
                img, 
                cropX, 
                cropY, 
                cropSize, 
                cropSize, 
                0, 
                0, 
                canvas.width, 
                canvas.height
            );

            // Replace the image with the canvas
            img.parentNode.replaceChild(canvas, img);
        };

        // Trigger the load event for already loaded images
        if (img.complete) {
            img.onload();
        }
    });
};
