﻿<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Art Sketcher</title>
  <style>
      body {
          font-family: 'Helvetica Neue', Arial, sans-serif;
          background-color: #e0e0e0;
          margin: 0;
          padding: 0;
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100vh;
          color: #333;
      }

      a {
          color: #008CBA;
          text-decoration: none;
          transition: color 0.3s ease;
      }

      a:hover {
          color: #005f73;
      }

      #container {
          background-color: #fff;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
          border-radius: 8px;
          padding: 20px;
          max-width: 800px;
          width: 100%;
          text-align: center;
      }

      img {
          border-radius: 4px;
          max-width: 100%;
          height: auto;
      }

      .gallery {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
          justify-content: center;
          margin-top: 20px;
      }

      .gallery a {
          flex: 1 1 calc(50% - 10px);
      }

      @media (max-width: 600px) {
          .gallery a {
              flex: 1 1 calc(100% - 10px);
          }
      }
  </style>
</head>
<body>
  <?php
      // Create directories if they don't exist
      $directories = ['img', 'comments'];
      foreach ($directories as $dir) {
          if (!file_exists($dir)) {
              mkdir($dir, 0777, true);
          }
      }

      // Image generation
      $width = 800;
      $height = 600;
      $outputImage = imagecreatetruecolor($width, $height);

      // Generate random background and line colors
      $bgColor = imagecolorallocate($outputImage, rand(0, 255), rand(0, 255), rand(0, 255));
      $lineColor = imagecolorallocate($outputImage, rand(0, 255), rand(0, 255), rand(0, 255));
      imagefill($outputImage, 0, 0, $bgColor);

      // Draw random lines
      $numLines = rand(5, 15);
      $startX = rand(0, $width);
      $startY = rand(0, $height);

      for ($i = 0; $i < $numLines; $i++) {
          $endX = rand(0, $width);
          $endY = rand(0, $height);
          imageline($outputImage, $startX, $startY, $endX, $endY, $lineColor);
          $startX = $endX;
          $startY = $endY;
      }

      // Save the image
      include("counter.php");
      $outputFilename = "img/$counter.jpg";
      imagejpeg($outputImage, $outputFilename);
      imagedestroy($outputImage);

      $lastPicture = "<a href='comment.php?hash=$outputFilename'><img src='$outputFilename' alt='Generated Sketch'></a>";
  ?>

  <div id="container">
      <h1>Art Sketcher</h1>
      <p>Generator of simple and minimalist design sketches</p>
      <div class="gallery">
          <?php echo $lastPicture; ?>
          <?php for ($i = 0; $i < 6; $i++) : ?>
              <?php $randomImage = rand(0, $counter); ?>
              <a href="comment.php?hash=img/<?php echo $randomImage; ?>.jpg" target="_blank">
                  <img src="img/<?php echo $randomImage; ?>.jpg" alt="Random Sketch">
              </a>
          <?php endfor; ?>
      </div>
  </div>
</body>
</html>
