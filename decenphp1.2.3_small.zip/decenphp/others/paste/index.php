﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content Saver</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            font-size: 2em;
            margin-bottom: 20px;
        }

        .container-entry {
            width: 100%;
            max-width: 600px;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        textarea {
            width: 600px;
            height: 150px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            resize: none; /* Prevents resizing */
        }

        button {
            background-color: #007BFF; /* Bootstrap primary color */
            color: white;
            border: none;
            border-radius: 4px;
            padding: 10px 15px;
            cursor: pointer;
            font-size: 1em;
        }

        button:hover {
            background-color: #0056b3; /* Darker shade on hover */
        }

        p {
            margin-top: 20px;
            font-size: 1em;
        }

        a {
            color: #007BFF; /* Link color */
            text-decoration: none; /* Remove underline */
        }

        a:hover {
            text-decoration: underline; /* Underline on hover */
        }
    </style>
</head>
<body>
    <h1>Content Saver</h1>
    <form method="post">
        <div class="container-entry">
            <label for="content">Paste your content here:</label>
            <textarea name="content" id="content" rows="8" required></textarea>
        </div>
        <button type="submit">Save Content</button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        // Create the folder if it doesn't exist
        if (!file_exists("paste")) {
            mkdir("paste", 0777, true);
        }

        $content = $_POST['content'];

        // Generate a SHA-256 hash of the content for the filename
        $filenameHash = hash('sha256', $content);
        $filename = 'paste/' . $filenameHash . '.txt';

        // Use fopen to write the content to the file
        $file = fopen($filename, 'a');
        if ($file) {
            if (fwrite($file, $content) !== false) {
                echo "<p>Content saved successfully in <a href='$filename' target='_blank'>$filename</a></p>";
            } else {
                echo '<p>Failed to write content to file. Please try again.</p>';
            }
            fclose($file);
        } else {
            echo '<p>Failed to open file for writing. Please try again.</p>';
        }
    }
    ?>
</body>
</html>