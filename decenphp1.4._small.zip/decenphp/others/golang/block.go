package main

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

// Directories for uploaded files and blockchain blocks
const (
	uploadDir    = "files/"
	blockDir     = "block/"
	maxFileSize  = 10 * 1024 * 1024 // 10MB
)

// Block structure
type Block struct {
	Username  string `json:"username"`
	FileName  string `json:"file_name"`
	FileHash  string `json:"file_hash"`
	Timestamp string `json:"timestamp"`
	PrevHash  string `json:"prev_hash"`
}

// Ensure the required directories exist
func init() {
	if _, err := os.Stat(uploadDir); os.IsNotExist(err) {
		err := os.Mkdir(uploadDir, 0755)
		if err != nil {
			log.Fatalf("Failed to create upload directory: %v", err)
		}
	}
	if _, err := os.Stat(blockDir); os.IsNotExist(err) {
		err := os.Mkdir(blockDir, 0755)
		if err != nil {
			log.Fatalf("Failed to create block directory: %v", err)
		}
	}
}

// Generate a SHA-256 hash for a given file
func generateFileHash(filePath string) (string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer file.Close()

	hash := sha256.New()
	if _, err := io.Copy(hash, file); err != nil {
		return "", err
	}

	return fmt.Sprintf("%x", hash.Sum(nil)), nil
}

// Create a block and save it to the block directory
func createBlock(username, fileHash, fileName, prevHash string) (string, error) {
	block := Block{
		Username:  username,
		FileName:  fileName,
		FileHash:  fileHash,
		Timestamp: time.Now().Format("2006-01-02 15:04:05"),
		PrevHash:  prevHash,
	}

	// Convert block to JSON
	blockData, err := json.MarshalIndent(block, "", "  ")
	if err != nil {
		return "", err
	}

	// Save the block to a file
	blockFileName := filepath.Join(blockDir, strconv.FormatInt(time.Now().Unix(), 10)+".block")
	err = writeToFile(blockFileName, blockData)
	if err != nil {
		return "", err
	}

	// Return the hash of the block's content
	blockHash := sha256.Sum256(blockData)
	return fmt.Sprintf("%x", blockHash), nil
}

// writeToFile replaces os.WriteFile
func writeToFile(filename string, data []byte) error {
	file, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer file.Close()

	_, err = file.Write(data)
	if err != nil {
		return err
	}

	return nil
}

// readFromFile replaces os.ReadFile
func readFromFile(filename string) ([]byte, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	fileInfo, err := file.Stat()
	if err != nil {
		return nil, err
	}

	data := make([]byte, fileInfo.Size())
	_, err = file.Read(data)
	if err != nil {
		return nil, err
	}

	return data, nil
}

// File upload handler
func uploadFile(w http.ResponseWriter, r *http.Request) {
	// Limit the size of the file
	r.ParseMultipartForm(maxFileSize)
	file, fileHeader, err := r.FormFile("uploadedFile")
	if err != nil {
		http.Error(w, "File upload error", http.StatusBadRequest)
		return
	}
	defer file.Close()

	// Check the file size
	if fileHeader.Size > maxFileSize {
		http.Error(w, "File exceeds 10MB size limit", http.StatusBadRequest)
		return
	}

	// Check file extension (disallow .php files)
	fileName := fileHeader.Filename
	fileExtension := strings.ToLower(filepath.Ext(fileName))
	if fileExtension == ".php" {
		http.Error(w, "PHP files are not allowed", http.StatusBadRequest)
		return
	}

	// Save the uploaded file to the files directory
	filePath := filepath.Join(uploadDir, fileName)
	outFile, err := os.Create(filePath)
	if err != nil {
		http.Error(w, "Unable to save the file", http.StatusInternalServerError)
		return
	}
	defer outFile.Close()

	// Copy the uploaded file to the server
	_, err = io.Copy(outFile, file)
	if err != nil {
		http.Error(w, "Unable to copy the file", http.StatusInternalServerError)
		return
	}

	// Generate the hash for the uploaded file
	fileHash, err := generateFileHash(filePath)
	if err != nil {
		http.Error(w, "Unable to generate file hash", http.StatusInternalServerError)
		return
	}

	// Check the previous block hash
	var prevHash string
	lastBlockHashFile := filepath.Join(blockDir, "last_block.hash")
	if _, err := os.Stat(lastBlockHashFile); os.IsNotExist(err) {
		prevHash = "0" // Genesis block
	} else {
		prevHashBytes, err := readFromFile(lastBlockHashFile)
		if err != nil {
			http.Error(w, "Unable to read last block hash", http.StatusInternalServerError)
			return
		}
		prevHash = string(prevHashBytes)
	}

	// Create a new block in the blockchain
	username := "defaultUser" // Replace this with actual user session data in real scenarios
	newBlockHash, err := createBlock(username, fileHash, fileName, prevHash)
	if err != nil {
		http.Error(w, "Unable to create blockchain block", http.StatusInternalServerError)
		return
	}

	// Save the new block's hash as the last block
	err = writeToFile(lastBlockHashFile, []byte(newBlockHash))
	if err != nil {
		http.Error(w, "Unable to save last block hash", http.StatusInternalServerError)
		return
	}

	// Success response
	fmt.Fprintf(w, "File uploaded successfully and blockchain updated")
}

func main() {
	// File upload route
	http.HandleFunc("/upload", uploadFile)

	// Serve HTML form for file upload
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, `
			<!DOCTYPE html>
			<html>
				<head>
					<title>Upload File</title>
				</head>
				<body>
					<form action="/upload" method="post" enctype="multipart/form-data">
						Select file to upload (Max 10MB):
						<input type="file" name="uploadedFile" required>
						<input type="submit" value="Upload File">
					</form>
				</body>
			</html>
		`)
	})

	// Start the HTTP server
	fmt.Println("Server started at http://localhost:8080")
	http.ListenAndServe(":8080", nil)
}
