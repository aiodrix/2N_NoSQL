<?php
// Database connection settings
$host = 'localhost';
$dbname = 'decenphp';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Fetch existing user_ids from the users table
function getUserIds($conn) {
    $stmt = $conn->query("SELECT user_id FROM users");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

// Function to insert random data into the invest table
function populateInvestTable($conn, $numRecords = 10) {
    $userIds = getUserIds($conn);  // Fetch valid user IDs
    if (empty($userIds)) {
        die("No users found in the 'users' table. Please add users before running this script.");
    }

    $fileHashes = ['abc123', 'def456', 'ghi789', 'jkl012', 'mno345'];  // Sample file hashes

    $sql = "INSERT INTO invest (user_id, file_hash, amount, transaction_date) VALUES (:user_id, :file_hash, :amount, :transaction_date)";
    $stmt = $conn->prepare($sql);

    for ($i = 0; $i < $numRecords; $i++) {
        $userId = $userIds[array_rand($userIds)];  // Random valid user ID
        $fileHash = $fileHashes[array_rand($fileHashes)];  // Random file hash
        $amount = rand(10, 1000) / 10;  // Random amount between 1.0 and 100.0
        $transactionDate = date('Y-m-d H:i:s', strtotime('-' . rand(1, 30) . ' days'));  // Random date within the last month

        // Bind parameters and execute
        $stmt->execute([
            ':user_id' => $userId,
            ':file_hash' => $fileHash,
            ':amount' => $amount,
            ':transaction_date' => $transactionDate,
        ]);
    }

    echo "$numRecords records inserted into the invest table.\n";
}

// Insert data into the table
populateInvestTable($conn, 10);

// Close the database connection
$conn = null;
