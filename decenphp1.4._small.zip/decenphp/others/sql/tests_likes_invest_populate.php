<?php

// Database connection configuration
$config = [
    'host' => 'localhost',
    'dbname' => 'decenphp',
    'username' => 'root',
    'password' => ''
];

try {
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8mb4",
        $config['username'],
        $config['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // First, create some sample files if they don't exist
    $createFilesTable = "
        CREATE TABLE IF NOT EXISTS files (
            id INT PRIMARY KEY AUTO_INCREMENT,
            hash VARCHAR(128) NOT NULL,
            name VARCHAR(255) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    $pdo->exec($createFilesTable);

    // Insert sample files
    $sampleFiles = [
        ['hash' => 'file1hash123', 'name' => 'sample1.jpg'],
        ['hash' => 'file2hash456', 'name' => 'sample2.jpg'],
        ['hash' => 'file3hash789', 'name' => 'sample3.jpg'],
        ['hash' => 'file4hash012', 'name' => 'sample4.jpg']
    ];

    $insertFileStmt = $pdo->prepare("INSERT IGNORE INTO files (hash, name) VALUES (:hash, :name)");
    foreach ($sampleFiles as $file) {
        $insertFileStmt->execute($file);
    }

    // Function to generate random dates within a range
    function randomDate($start_date, $end_date) {
        $min = strtotime($start_date);
        $max = strtotime($end_date);
        $random_timestamp = mt_rand($min, $max);
        return date('Y-m-d H:i:s', $random_timestamp);
    }

    // Populate invest table
    $userIds = range(1, 5); // Sample user IDs from 1 to 5
    $amounts = [10.00, 20.00, 50.00, 100.00, 200.00];

    $insertInvestStmt = $pdo->prepare("
        INSERT INTO invest (user_id, file_hash, amount, transaction_date)
        VALUES (:user_id, :file_hash, :amount, :transaction_date)
    ");

    // Generate 20 investment records
    for ($i = 0; $i < 20; $i++) {
        $data = [
            ':user_id' => $userIds[array_rand($userIds)],
            ':file_hash' => $sampleFiles[array_rand($sampleFiles)]['hash'],
            ':amount' => $amounts[array_rand($amounts)],
            ':transaction_date' => randomDate('2024-01-01', '2024-03-13')
        ];
        $insertInvestStmt->execute($data);
    }

    // Populate likes table
    $actions = ['like', 'dislike'];
    $userIps = ['192.168.1.1', '192.168.1.2', '192.168.1.3', '192.168.1.4'];
    $usernames = ['user1', 'user2', 'user3', 'user4', 'user5'];

    // Get file IDs
    $stmt = $pdo->query("SELECT id FROM files");
    $fileIds = $stmt->fetchAll(PDO::FETCH_COLUMN);

    $insertLikeStmt = $pdo->prepare("
        INSERT INTO likes (interaction_hash, file_id, user_ip, username, action, timestamp)
        VALUES (:interaction_hash, :file_id, :user_ip, :username, :action, :timestamp)
    ");

    // Generate 50 like/dislike records
    for ($i = 0; $i < 50; $i++) {
        $username = $usernames[array_rand($usernames)];
        $fileId = $fileIds[array_rand($fileIds)];
        $timestamp = randomDate('2024-02-13', '2024-03-13'); // Last month of data
        
        $data = [
            ':interaction_hash' => md5($username . $fileId . $timestamp),
            ':file_id' => $fileId,
            ':user_ip' => $userIps[array_rand($userIps)],
            ':username' => $username,
            ':action' => $actions[array_rand($actions)],
            ':timestamp' => $timestamp
        ];
        
        try {
            $insertLikeStmt->execute($data);
        } catch (PDOException $e) {
            // Ignore duplicate interaction_hash errors
            if ($e->getCode() != 23000) throw $e;
        }
    }

    echo "Database populated successfully!\n";
    echo "Summary:\n";
    
    // Display summary of inserted data
    $stats = [
        'Files' => $pdo->query("SELECT COUNT(*) FROM files")->fetchColumn(),
        'Investments' => $pdo->query("SELECT COUNT(*) FROM invest")->fetchColumn(),
        'Likes/Dislikes' => $pdo->query("SELECT COUNT(*) FROM likes")->fetchColumn(),
        'Unique Users with Investments' => $pdo->query("SELECT COUNT(DISTINCT user_id) FROM invest")->fetchColumn(),
        'Total Investment Amount' => $pdo->query("SELECT SUM(amount) FROM invest")->fetchColumn()
    ];

    foreach ($stats as $label => $value) {
        echo "$label: " . ($label == 'Total Investment Amount' ? '$' . number_format($value, 2) : $value) . "\n";
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "Code: " . $e->getCode() . "\n";
}

?>