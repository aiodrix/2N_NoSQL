<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Art Sketcher</title>
  <style>
      body {
          font-family: 'Helvetica Neue', Arial, sans-serif;
          background-color: #f5f5f5;
          margin: 0;
          padding: 0;
          display: flex;
          justify-content: center;
          align-items: center;
          min-height: 100vh;
          color: #333;
      }

      a {
          color: #008CBA;
          text-decoration: none;
          transition: color 0.3s ease;
      }

      a:hover {
          color: #005f73;
      }

      #container {
          background-color: #fff;
          box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
          border-radius: 12px;
          padding: 40px;
          max-width: 900px;
          width: 100%;
          text-align: center;
      }

      h1 {
          font-size: 2.5em;
          color: #444;
          margin-bottom: 10px;
      }

      p {
          color: #666;
          font-size: 1.2em;
          margin-bottom: 30px;
      }

      img {
          border-radius: 12px;
          max-width: 100%;
          height: auto;
          transition: transform 0.3s ease, box-shadow 0.3s ease;
          box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      }

      img:hover {
          transform: scale(1.05);
          box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      }

      .gallery {
          display: flex;
          flex-wrap: wrap;
          gap: 15px;
          justify-content: center;
      }

      .gallery a {
          flex: 1 1 calc(33% - 30px);
          max-width: 300px;
      }

      @media (max-width: 800px) {
          .gallery a {
              flex: 1 1 calc(50% - 15px);
          }
      }

      @media (max-width: 500px) {
          .gallery a {
              flex: 1 1 100%;
          }
      }
  </style>
</head>
<body>
  <?php
      // Create directories if they don't exist
      $directories = ['img', 'comments'];
      foreach ($directories as $dir) {
          if (!file_exists($dir)) {
              mkdir($dir, 0777, true);
          }
      }

      // Image generation
      $width = 800;
      $height = 600;
      $outputImage = imagecreatetruecolor($width, $height);

      // Generate random background and line colors
      $bgColor = imagecolorallocate($outputImage, rand(200, 255), rand(200, 255), rand(200, 255)); // Light colors for smoothness
      $lineColor = imagecolorallocate($outputImage, rand(0, 180), rand(0, 180), rand(0, 180)); // Darker lines for contrast
      imagefill($outputImage, 0, 0, $bgColor);

      // Draw random lines
      $numLines = rand(5, 15);
      $startX = rand(0, $width);
      $startY = rand(0, $height);

      for ($i = 0; $i < $numLines; $i++) {
          $endX = rand(0, $width);
          $endY = rand(0, $height);
          imageline($outputImage, $startX, $startY, $endX, $endY, $lineColor);
          $startX = $endX;
          $startY = $endY;
      }

      // Save the image
      include("counter.php");
      $outputFilename = "img/$counter.jpg";
      imagejpeg($outputImage, $outputFilename, 90); // Save with better quality
      imagedestroy($outputImage);

      $lastPicture = "<a href='$outputFilename' target='_blank'><img src='$outputFilename' alt='Generated Sketch'></a>";
  ?>

  <div id="container">
      <h1>Art Sketcher</h1>
      <p>Generator of simple and minimalist design patterns</p>
      <div class="gallery">
          <?php echo $lastPicture; ?>
          <?php for ($i = 0; $i < 6; $i++) : ?>
              <?php $randomImage = rand(0, $counter); ?>
              <a href="glitch.php?img=img/<?php echo $randomImage; ?>.jpg" target="_blank">
                  <img src="img/<?php echo $randomImage; ?>.jpg" alt="Random Sketch">
              </a>
          <?php endfor; ?>
      </div>
  </div>
</body>
</html>
