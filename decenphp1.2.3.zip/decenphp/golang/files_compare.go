package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

// Function to check the URL
func checkURL(url string) {
	client := http.Client{
		Timeout: 10 * 1000000000, // 10 seconds
	}

	resp, err := client.Get(url)
	if err != nil {
		fmt.Printf("Failed to connect to %s: %v\n", url, err)
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode == 200 {
		fmt.Printf("Successfully connected to %s\n", url)
	} else {
		fmt.Printf("Failed to connect to %s (HTTP Code: %d)\n", url, resp.StatusCode)
	}
}

// Function to compare local file contents with remote file contents
func checkFilesAtURLAndCompare(url string) {
	const filesDir = "files"
	const maxFileSize = 10 * 1024 * 1024 // 10 MB

	// Check if 'files' directory exists
	if _, err := os.Stat(filesDir); os.IsNotExist(err) {
		fmt.Printf("Directory '%s' does not exist.\n", filesDir)
		return
	}

	// Read files in the directory
	files, err := ioutil.ReadDir(filesDir)
	if err != nil {
		fmt.Printf("Failed to read directory '%s': %v\n", filesDir, err)
		return
	}

	fmt.Printf("Checking if files from 'files' directory exist and are identical at the URL: %s\n", url)

	for _, file := range files {
		// Skip directories
		if file.IsDir() {
			continue
		}

		filePath := filepath.Join(filesDir, file.Name())

		// Skip files larger than 10 MB
		if file.Size() > maxFileSize {
			fmt.Printf("File %s is larger than 10MB and will not be checked.\n", file.Name())
			continue
		}

		fileURL := strings.TrimRight(url, "/") + "/" + file.Name()
		fmt.Printf("Checking file: %s at URL: %s\n", file.Name(), fileURL)

		// Fetch remote file content
		resp, err := http.Get(fileURL)
		if err != nil {
			fmt.Printf("Failed to connect to %s: %v\n", fileURL, err)
			continue
		}
		defer resp.Body.Close()

		// Check if the response body is not nil
		if resp.Body == nil {
			fmt.Printf("Error: No content at %s\n", fileURL)
			continue
		}

		// Read the remote content
		remoteContent, err := ioutil.ReadAll(resp.Body)
		if err != nil {
			fmt.Printf("Error reading remote file %s: %v\n", file.Name(), err)
			continue
		}

		// Read local file content
		localContent, err := ioutil.ReadFile(filePath)
		if err != nil {
			fmt.Printf("Failed to read local file %s: %v\n", file.Name(), err)
			continue
		}

		// Compare contents
		if string(localContent) == string(remoteContent) {
			fmt.Printf("File %s is identical to the file at %s\n", file.Name(), fileURL)
		} else {
			fmt.Printf("File %s is different from the file at %s\n", file.Name(), fileURL)
		}
	}
}

// Main function
func main() {
	const serversDir = "servers"

	// Check if 'servers' directory exists
	if _, err := os.Stat(serversDir); os.IsNotExist(err) {
		fmt.Printf("Directory '%s' does not exist.\n", serversDir)
		return
	}

	// Read files in the 'servers' directory
	files, err := ioutil.ReadDir(serversDir)
	if err != nil {
		fmt.Printf("Failed to read directory '%s': %v\n", serversDir, err)
		return
	}

	fmt.Println("Attempting to connect to URLs from files in the 'servers' folder:")

	for _, file := range files {
		// Skip directories
		if file.IsDir() {
			continue
		}

		filePath := filepath.Join(serversDir, file.Name())
		fmt.Printf("File: %s\n", file.Name())

		// Get the file content
		fileContent, err := ioutil.ReadFile(filePath)
		if err != nil {
			fmt.Printf("Failed to read file %s: %v\n", file.Name(), err)
			continue
		}

		// Check if the content is a valid URL
		url := strings.TrimSpace(string(fileContent))
		if strings.HasPrefix(url, "http://") || strings.HasPrefix(url, "https://") {
			fmt.Printf("Attempting connection to: %s\n", url)
			checkURL(url)
			checkFilesAtURLAndCompare(url)
		} else {
			fmt.Printf("Invalid URL or empty file content: %s\n", url)
		}
	}
}
